package com.example.synod.message;

public class Launch {
}
