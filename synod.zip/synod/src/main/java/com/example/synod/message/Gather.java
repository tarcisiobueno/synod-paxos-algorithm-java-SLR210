package com.example.synod.message;

public class Gather {
    public int ballot;
    public int estballot;
    public Boolean est;
    public int i;

    public Gather(int ballot, int estballot, Boolean est, int i) {
        this.ballot = ballot;
        this.estballot = estballot;
        this.est = est;
        this.i = i;
    }
}
