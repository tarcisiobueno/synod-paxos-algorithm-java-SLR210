package com.example.synod.message;

public class Ack {
    public int ballot;

    public Ack(int ballot) {
        this.ballot = ballot;
    }
}
