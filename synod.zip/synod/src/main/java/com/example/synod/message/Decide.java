package com.example.synod.message;

public class Decide {
    public Boolean v;

    public Decide(Boolean v) {
        this.v = v;
    }
}
