package com.example.synod.message;

public class Impose {
    public int ballot;
    public Boolean v;

    public Impose(int ballot, Boolean v) {
        this.ballot = ballot;
        this.v = v;
    }
}
